import java.util.ArrayList;
import java.util.List;

public class PetShop {

    private String nomeLoja;
    private List<Servico> servicosDoDia;

    public PetShop(String nomeLoja) {
        this.nomeLoja = nomeLoja;
        this.servicosDoDia = new ArrayList<>();
    }

    public void registrarServico(Servico servico) {
        servicosDoDia.add(servico);
    }

    public int getQuantidadeServicos() {
        return servicosDoDia.size();
    }

    /**
     * Gera o texto do inventário de serviços realizados no dia,
     * incluindo o faturamento total.
     */
    public String gerarInventarioDoDia() {
        StringBuilder sb = new StringBuilder();
        sb.append("===========================================\n");
        sb.append("   INVENTÁRIO DE SERVIÇOS - ").append(nomeLoja).append("\n");
        sb.append("===========================================\n");

        if (servicosDoDia.isEmpty()) {
            sb.append("Nenhum serviço foi realizado hoje.\n");
        } else {
            double total = 0;
            for (int i = 0; i < servicosDoDia.size(); i++) {
                Servico servico = servicosDoDia.get(i);
                sb.append((i + 1)).append(". ").append(servico).append("\n");
                total += servico.getValor();
            }
            sb.append("-------------------------------------------\n");
            sb.append("Total de serviços: ").append(servicosDoDia.size()).append("\n");
            sb.append(String.format("Faturamento do dia: R$ %.2f%n", total));
        }

        sb.append("===========================================\n");
        return sb.toString();
    }
}
