import java.util.Scanner;

public class MainRoboPetShop {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        PetShop petShop = new PetShop("Petshop Amigo Fiel");

        System.out.println("🐾 Olá! Eu sou o RoboPet, assistente virtual do Petshop Amigo Fiel!");
        System.out.println("Digite 'menu' a qualquer momento para ver as opções.\n");

        boolean lojaAberta = true;

        while (lojaAberta) {
            exibirMenu();
            String opcao = scanner.nextLine().trim();

            switch (opcao) {
                case "1":
                    registrarNovoServico(scanner, petShop);
                    break;

                case "2":
                    System.out.println("\n🔒 Fechando a loja... gerando o inventário do dia:\n");
                    System.out.println(petShop.gerarInventarioDoDia());
                    System.out.println("👋 Até amanhã! O RoboPet está encerrando.");
                    lojaAberta = false;
                    break;

                default:
                    System.out.println("❌ Opção inválida! Digite 1 ou 2.\n");
            }
        }

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("----------------------------------------");
        System.out.println("🐶 MENU RoboPet 🐱");
        System.out.println("1 - Registrar novo serviço realizado");
        System.out.println("2 - Fechar a loja (imprime inventário do dia)");
        System.out.println("----------------------------------------");
        System.out.print("Escolha uma opção: ");
    }

    private static void registrarNovoServico(Scanner scanner, PetShop petShop) {
        System.out.print("\n🐕 Qual o nome do pet? ");
        String nomePet = scanner.nextLine();

        System.out.print("👤 Qual o nome do dono(a)? ");
        String nomeCliente = scanner.nextLine();

        System.out.println("🛁 Qual serviço foi realizado?");
        System.out.println("   1 - Banho");
        System.out.println("   2 - Tosa");
        System.out.println("   3 - Consulta veterinária");
        System.out.println("   4 - Hospedagem");
        System.out.print("Escolha o número do serviço: ");
        String opcaoServico = scanner.nextLine().trim();

        String tipoServico;
        double valorSugerido;

        switch (opcaoServico) {
            case "1":
                tipoServico = "Banho";
                valorSugerido = 50.0;
                break;
            case "2":
                tipoServico = "Tosa";
                valorSugerido = 70.0;
                break;
            case "3":
                tipoServico = "Consulta";
                valorSugerido = 120.0;
                break;
            case "4":
                tipoServico = "Hospedagem";
                valorSugerido = 90.0;
                break;
            default:
                tipoServico = "Outro";
                valorSugerido = 0.0;
        }

        System.out.print("💰 Valor cobrado (sugestão R$ " + valorSugerido + "): R$ ");
        String entradaValor = scanner.nextLine().trim();

        double valor;
        try {
            valor = entradaValor.isEmpty() ? valorSugerido : Double.parseDouble(entradaValor);
        } catch (NumberFormatException e) {
            System.out.println("⚠️ Valor inválido, usando o valor sugerido.");
            valor = valorSugerido;
        }

        Servico servico = new Servico(tipoServico, nomeCliente, nomePet, valor);
        petShop.registrarServico(servico);

        System.out.println("✅ Serviço registrado com sucesso! (" + petShop.getQuantidadeServicos()
                + " serviço(s) hoje)\n");
    }
}
