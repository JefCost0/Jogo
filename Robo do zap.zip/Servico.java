public class Servico {

    private String tipoServico;
    private String nomeCliente;
    private String nomePet;
    private double valor;

    public Servico(String tipoServico, String nomeCliente, String nomePet, double valor) {
        this.tipoServico = tipoServico;
        this.nomeCliente = nomeCliente;
        this.nomePet = nomePet;
        this.valor = valor;
    }

    public String getTipoServico() {
        return tipoServico;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public String getNomePet() {
        return nomePet;
    }

    public double getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return String.format("%-12s | Pet: %-10s | Dono: %-10s | R$ %.2f",
                tipoServico, nomePet, nomeCliente, valor);
    }
}
