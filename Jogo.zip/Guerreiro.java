public class Guerreiro extends Personagem {

    public Guerreiro(String nome) {
        super(nome);
    }

    public Guerreiro(String nome, int nivel) {
        super(nome, nivel);
    }

    @Override
    protected int calcularDano() {
        int dano = getNivel() * 8;
        if (getNivel() > 10) {
            dano += 2;
        }
        return dano;
    }
}
