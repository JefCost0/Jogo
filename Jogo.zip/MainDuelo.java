public class MainDuelo {

    public static void main(String[] args) {

        Personagem mago = new Mago("Mago", 5);
        Personagem guerreiro = new Guerreiro("Guerreiro", 5);

        Duelo duelo = new Duelo(mago, guerreiro);
        duelo.iniciarDuelo();

        System.out.println("\n--- Relatório completo do duelo ---");
        System.out.println(duelo.gerarRelatorio());
    }
}
