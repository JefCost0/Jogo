public abstract class Personagem {

    private String nome;
    private int nivel;
    private int pontosDeVida;

    protected Personagem(String nome) {
        this(nome, 1);
    }

    protected Personagem(String nome, int nivel) {
        this.nome = nome;
        this.nivel = nivel;
        this.pontosDeVida = 100 + 10 * nivel;
    }

    /**
     * Calcula o dano do ataque, de acordo com a fórmula específica de cada tipo de personagem.
     * Método que cada subclasse (Guerreiro, Mago, Arqueiro) deve implementar.
     */
    protected abstract int calcularDano();

    /**
     * O personagem ataca o oponente. Retorna o dano causado.
     * Se o ataque zerar os pontos de vida do oponente, quem atacou sobe de nível.
     */
    public int atacar(Personagem oponente) {
        int dano = calcularDano();
        oponente.serAtacado(dano);

        if (!oponente.estaVivo()) {
            this.subirDeNivel();
        }

        return dano;
    }

    /**
     * Reduz os pontos de vida do personagem pelo dano recebido.
     * Retorna os pontos de vida atuais após o ataque.
     */
    public int serAtacado(int dano) {
        pontosDeVida -= dano;
        if (pontosDeVida < 0) {
            pontosDeVida = 0;
        }
        return pontosDeVida;
    }

    public boolean estaVivo() {
        return pontosDeVida > 0;
    }

    public int getPontosDeVida() {
        return pontosDeVida;
    }

    public void subirDeNivel() {
        nivel++;
    }

    public String getNome() {
        return nome;
    }

    public int getNivel() {
        return nivel;
    }
}
