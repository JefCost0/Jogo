public class Mago extends Personagem {

    public Mago(String nome) {
        super(nome);
    }

    public Mago(String nome, int nivel) {
        super(nome, nivel);
    }

    @Override
    protected int calcularDano() {
        return getNivel() * getNivel() + 2;
    }
}
