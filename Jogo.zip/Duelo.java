import java.util.ArrayList;
import java.util.List;

public class Duelo {

    private Personagem personagem1;
    private Personagem personagem2;
    private List<String> relatorio;
    private int numeroRodada;

    public Duelo(Personagem personagem1, Personagem personagem2) {
        this.personagem1 = personagem1;
        this.personagem2 = personagem2;
        this.relatorio = new ArrayList<>();
        this.numeroRodada = 0;
    }

    /**
     * O personagem "atacante" ataca o personagem "defensor" nesta rodada.
     * Registra a rodada no relatório e retorna uma String indicando
     * se o personagem atacado continua vivo.
     */
    public String duelar(Personagem atacante, Personagem defensor) {
        numeroRodada++;

        atacante.atacar(defensor); // chamada polimórfica: calcularDano() varia conforme o tipo real do personagem

        String linha = "Rodada " + numeroRodada + ": " + atacante.getNome()
                + " ataca " + defensor.getNome()
                + ", pontuação de vida do " + defensor.getNome()
                + " = " + defensor.getPontosDeVida();

        relatorio.add(linha);

        if (defensor.estaVivo()) {
            return defensor.getNome() + " ainda está vivo.";
        } else {
            return defensor.getNome() + " foi derrotado!";
        }
    }

    /**
     * Executa o duelo completo, com personagem1 e personagem2 atacando de forma
     * alternada, até que um deles fique sem pontos de vida.
     */
    public void iniciarDuelo() {
        Personagem atacante = personagem1;
        Personagem defensor = personagem2;

        while (personagem1.estaVivo() && personagem2.estaVivo()) {
            String resultado = duelar(atacante, defensor);
            System.out.println(resultado);

            // troca quem ataca e quem defende na próxima rodada
            Personagem temp = atacante;
            atacante = defensor;
            defensor = temp;
        }

        Personagem vencedor = personagem1.estaVivo() ? personagem1 : personagem2;
        System.out.println("\nVencedor: " + vencedor.getNome() + " (nível " + vencedor.getNivel() + ")");
    }

    public String gerarRelatorio() {
        StringBuilder sb = new StringBuilder();
        for (String linha : relatorio) {
            sb.append(linha).append("\n");
        }
        return sb.toString();
    }
}
