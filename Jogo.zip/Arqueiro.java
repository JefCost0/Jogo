public class Arqueiro extends Personagem {

    public Arqueiro(String nome) {
        super(nome);
    }

    public Arqueiro(String nome, int nivel) {
        super(nome, nivel);
    }

    @Override
    protected int calcularDano() {
        double precisao = 0.8 + (getNivel() * 0.02);
        return (int) (getNivel() * 10 * precisao);
    }
}
